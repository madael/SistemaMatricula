package exercicios;

public class Aluno {
    
    private String nome;
    private String cpf;
    
    public Aluno(){
        nome="";
        cpf="";
    }
    
    public Aluno(String nome, String cpf){
        this.nome=nome;
        this.cpf=cpf;        
    }
    
    
    public void imprimir(){
        System.out.println("Nome: "+this.getNome()+"; CPF: "+this.getCpf());
    }
    
    public void imprimir(int text){
        System.out.println("Nome: "+this.getNome()+"; CPF: "+this.getCpf()+"; Código: "+text);
    }
    
    public String criarCSV(){
        return "Nome: "+ this.nome+" CPF: "+this.cpf;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpf to set
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    
}
