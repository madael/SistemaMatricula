package exercicios;

public class Curso {
    private String nome;
    private double cargaHorario;
    
    public Curso(){
        nome="";
        cargaHorario=0;
    }
    
    public void imprimir(){
        System.out.println("Curso: "+this.getNome()+"; Carga horaria: "+this.getCargaHorario());
    }
    
    public void imprimir(int text){
        System.out.println("Curso: "+this.getNome()+"; Carga horaria: "+this.getCargaHorario()+"; Código: "+text);
    }
    
    public String criarCSV(){
        return this.nome+";"+Double.toString(this.cargaHorario);
    }
    
    public void convertString(String texto){
        String[] split = texto.split(";");
        this.nome = split[0];
        this.cargaHorario = Double.parseDouble(split[1]);
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the cargaHorario
     */
    public double getCargaHorario() {
        return cargaHorario;
    }

    /**
     * @param cargaHorario the cargaHorario to set
     */
    public void setCargaHorario(double cargaHorario) {
        this.cargaHorario = cargaHorario;
    }
    
}
