package exercicios;

import java.util.Scanner;

public class Matricula {
    private String data;
    private Aluno aluno;
    private Curso curso;
    
    public Matricula(){
        data="";
        aluno=new Aluno();
        curso=new Curso();
    }
    
    public String criarCSV(){
        return this.aluno.criarCSV()+ ";"+ this.curso.criarCSV()+";"+this.data;
    }
    
    public void matricular(Curso curso){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o nome do aluno: ");
        aluno.setNome(scanner.nextLine());
        System.out.println("Digite o CPF do aluno: ");
        aluno.setCpf(scanner.nextLine());
        System.out.println("Digite a data: ");
        this.setData(scanner.nextLine());
        this.setCurso(curso);        
    }
    
    public void matricular(Aluno aluno, Curso curso,String data){
        this.setAluno(aluno);
        this.setCurso(curso);
        this.setData(data);
    }
    
    public void imprimir(){
        System.out.println("Nome: "+aluno.getNome()+"; Curso: "+curso.getNome());
    }
    
    public void imprimir(String texto){
        System.out.println("Nome: "+aluno.getNome()+"; Curso: "+curso.getNome()+"; "+texto);
    }

    /**
     * @return the data
     */
    public String getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     * @return the aluno
     */
    public Aluno getAluno() {
        return aluno;
    }

    /**
     * @param aluno the aluno to set
     */
    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    /**
     * @return the curso
     */
    public Curso getCurso() {
        return curso;
    }

    /**
     * @param curso the curso to set
     */
    public void setCurso(Curso curso) {
        this.curso = curso;
    }
    
    
}
