package exercicios;


public class LpsAlunoCursoMatricula {

    public static void main(String[] args) {
        Menu.rodar();
    }

}
