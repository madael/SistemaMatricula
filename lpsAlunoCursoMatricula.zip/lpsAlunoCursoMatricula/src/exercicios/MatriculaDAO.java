/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicios;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Daniel Lucarelli
 */
public class MatriculaDAO {
    public static void adiciona(Matricula matricula) {
        String sql = "INSERT INTO matricula(nome,cpf) VALUES(?,?)";
        try {
            PreparedStatement stmt = ConexaoBD.conexao().prepareStatement(sql);
            stmt.setString(1, matricula.getNome());
            stmt.setString(2, matricula.getCpf());
            System.out.println(stmt.toString());
            stmt.execute();
            stmt.close();

        } catch (SQLException u) {
            System.out.println("Não foi possivel executar o sql");
        }
    }
    
    public static ArrayList<Matricula> consulta() {
        ArrayList<Matricula> list = new ArrayList<>();

        String sql = "Select * from aluno";
        String sqlM;
        String sqlC;
        try {
            PreparedStatement stmt = ConexaoBD.conexao().prepareStatement(sql);
            ResultSet resultset = stmt.executeQuery();
            while (resultset.next()) {
                sqlM = "Select * where codigo_aluno="+resultset.getInt(2)+" from aluno";
                Aluno a = new Aluno();
                sqlC = "Select * from aluno";
                Matricula a = new Matricula(resultset.getInt(1),, resultset.getInt(3),resultset.getString(4));
                list.add(a);
             }                           
            stmt.close();
        } catch (SQLException u) {
            System.out.println("Não foi possivel executar o sql");
        }

        return list;

    }
    
}
